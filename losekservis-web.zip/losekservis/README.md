# R-SERVIS LOŠEK – Web

Webová prezentace firmy R-SERVIS LOŠEK s.r.o.

## Struktura projektu

```
losekservis/
├── index.html          ← hlavní HTML soubor
├── css/
│   └── style.css       ← veškeré styly
├── js/
│   └── main.js         ← scroll reveal + formulář
├── img/                ← složka pro obrázky
│   ├── og-image.jpg    ← náhledový obrázek pro sdílení (1200×630 px)
│   └── tym-*.jpg       ← fotky členů týmu
└── README.md
```

---

## Nastavení formuláře (Formspree)

1. Jděte na https://formspree.io a zaregistrujte se (zdarma)
2. Klikněte **+ New Form** → zadejte název → potvrďte email pro doručování zpráv
3. Zkopírujte vaše **Form ID** (tvar: `xabc1234`)
4. Otevřete `js/main.js` a nahraďte:
   ```js
   const FORMSPREE_ID = 'YOUR_FORM_ID';
   ```
   vaším ID, např.:
   ```js
   const FORMSPREE_ID = 'xabc1234';
   ```

---

## Nasazení na GitHub Pages (krok za krokem)

### Co budete potřebovat
- Účet na [github.com](https://github.com) (zdarma)
- Nainstalovaný [Git](https://git-scm.com/downloads) nebo aplikaci [GitHub Desktop](https://desktop.github.com)

---

### Varianta A – přes prohlížeč (nejjednodušší, bez instalace)

1. Přihlaste se na **github.com**
2. Klikněte **+ → New repository**
3. Název repozitáře: `losekservis` (nebo cokoliv jiného)
4. Zaškrtněte **Public** → klikněte **Create repository**
5. Na stránce repozitáře klikněte **Add file → Upload files**
6. Přetáhněte celou složku projektu (index.html, css/, js/, img/)
7. Dole klikněte **Commit changes**
8. Jděte do **Settings → Pages**
9. Pod **Branch** vyberte `main` a složku `/ (root)` → klikněte **Save**
10. Po chvíli (1–2 min) se web zobrazí na adrese:
    ```
    https://vase-uzivatelske-jmeno.github.io/losekservis/
    ```

---

### Varianta B – přes terminál (pro pokročilé)

```bash
# 1. Inicializujte Git repozitář v složce projektu
cd losekservis
git init
git add .
git commit -m "První verze webu"

# 2. Vytvořte repozitář na GitHub a připojte ho
git remote add origin https://github.com/VASE-JMENO/losekservis.git
git branch -M main
git push -u origin main

# 3. Zapněte GitHub Pages v Settings → Pages → Branch: main
```

---

### Varianta C – přes GitHub Desktop (doporučeno pro méně technické uživatele)

1. Stáhněte [GitHub Desktop](https://desktop.github.com) a přihlaste se
2. **File → Add Local Repository** → vyberte složku `losekservis`
   - Pokud Git není inicializován, klikněte **Initialize Repository**
3. **Commit to main** → **Publish repository**
4. Zaškrtněte **Keep this code private: NE** (musí být Public pro Pages zdarma)
5. Klikněte **Publish Repository**
6. Na github.com jděte do **Settings → Pages** → Branch: `main` → **Save**

---

## Vlastní doména (volitelné)

Pokud chcete web na `www.losekservis.cz` místo GitHub adresy:

1. U svého poskytovatele domény nastavte DNS záznamy:
   ```
   CNAME  www   vase-jmeno.github.io
   A      @     185.199.108.153
   A      @     185.199.109.153
   A      @     185.199.110.153
   A      @     185.199.111.153
   ```
2. V GitHub → Settings → Pages → Custom domain → zadejte `www.losekservis.cz`
3. Zaškrtněte **Enforce HTTPS** (aktivuje se automaticky po ověření DNS, může trvat až 24h)
4. V `index.html` aktualizujte canonical URL a OG tagy na skutečnou doménu

---

## Přidání reálných fotek týmu

V `index.html` najděte sekci `#tym`. U každého člena je komentář:
```html
<!-- Reálná fotka: <img class="team-photo" src="img/tym-jan-losek.jpg" alt="Jan Lošek"> -->
<div class="team-photo-placeholder" ...>
```

Postup:
1. Připravte fotku (doporučený rozměr: 600×800 px, formát JPG)
2. Uložte ji do složky `img/` s názvem např. `tym-jan-losek.jpg`
3. Nahraďte celý blok `<div class="team-photo-placeholder">...</div>` za:
   ```html
   <img class="team-photo" src="img/tym-jan-losek.jpg" alt="Jan Lošek, jednatel R-SERVIS LOŠEK">
   ```

---

## Google Analytics (volitelné)

V `index.html` na konci `<head>` je připravený blok (zakomentovaný).
Odkomentujte ho a doplňte vaše Measurement ID (tvar `G-XXXXXXXXXX`).
